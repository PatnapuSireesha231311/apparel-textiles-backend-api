import { Router } from "express";
import { db } from "../db.js";
const router = Router();

router.get("/", (req, res) => {
  const q = String(req.query.q || "").trim().slice(0, 100);
  const category = String(req.query.category || "").trim().slice(0, 80);
  const rows = db.prepare(`
    SELECT p.id, p.name, p.slug, p.description, c.name AS category,
      v.id AS variantId, v.sku, v.size, v.colour, v.price_minor AS priceMinor,
      v.currency, (v.stock_quantity - v.reserved_quantity) AS availableStock
    FROM products p JOIN categories c ON c.id = p.category_id
    JOIN product_variants v ON v.product_id = p.id
    WHERE p.active = 1 AND (? = '' OR p.name LIKE '%' || ? || '%' OR p.description LIKE '%' || ? || '%')
      AND (? = '' OR c.slug = ?)
    ORDER BY p.id, v.id
  `).all(q, q, q, category, category);
  res.json({ data: rows });
});

router.get("/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: { code: "INVALID_ID", message: "Product ID must be a positive integer" } });
  const product = db.prepare("SELECT p.id, p.name, p.slug, p.description, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id WHERE p.id = ? AND p.active = 1").get(id);
  if (!product) return res.status(404).json({ error: { code: "NOT_FOUND", message: "Product not found" } });
  product.variants = db.prepare("SELECT id, sku, size, colour, price_minor AS priceMinor, currency, stock_quantity - reserved_quantity AS availableStock FROM product_variants WHERE product_id = ?").all(id);
  res.json({ data: product });
});
export default router;
