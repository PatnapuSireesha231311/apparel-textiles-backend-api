import { Router } from "express";
import { z } from "zod";
import { createOrder, getOrder } from "../services/orderService.js";
import { createDemoCheckout, confirmDemoPayment } from "../services/paymentService.js";

const router = Router();
const orderSchema = z.object({
  customer: z.object({
    name: z.string().trim().min(2).max(100),
    email: z.string().trim().email().max(254)
  }),
  address: z.object({
    line1: z.string().trim().min(3).max(160),
    city: z.string().trim().min(2).max(80),
    postalCode: z.string().trim().min(3).max(20),
    country: z.string().trim().length(2)
  }),
  items: z.array(z.object({
    variantId: z.number().int().positive(),
    quantity: z.number().int().min(1).max(10)
  })).min(1).max(30)
});

router.post("/", (req, res, next) => {
  try {
    const parsed = orderSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid order data", details: parsed.error.flatten() } });
    const order = createOrder(parsed.data);
    res.status(201).json({ data: order });
  } catch (err) { next(err); }
});

router.get("/:orderNumber", (req, res) => {
  // Demo only: production must require authenticated ownership or a high-entropy order access token.
  const order = getOrder(req.params.orderNumber);
  if (!order) return res.status(404).json({ error: { code: "NOT_FOUND", message: "Order not found" } });
  res.json({ data: order });
});

router.post("/:orderNumber/checkout-session", (req, res, next) => {
  try { res.status(201).json({ data: createDemoCheckout(req.params.orderNumber) }); }
  catch (err) { next(err); }
});

// DEMO ONLY: this route simulates a verified provider webhook. Do not expose this as a real payment endpoint.
router.post("/:orderNumber/demo-confirm-payment", (req, res, next) => {
  try {
    const result = confirmDemoPayment(req.params.orderNumber, "demo-payment-reference");
    res.json({ data: result, warning: "Demo confirmation only. Replace with a signed provider webhook before production." });
  } catch (err) { next(err); }
});

export default router;
