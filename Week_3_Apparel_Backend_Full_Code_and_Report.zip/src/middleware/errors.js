export function notFound(req, res) {
  res.status(404).json({ error: { code: "NOT_FOUND", message: "Route not found" } });
}
export function errorHandler(err, req, res, next) {
  console.error("request_error", { message: err.message, path: req.path });
  const status = Number.isInteger(err.status) ? err.status : 500;
  res.status(status).json({
    error: {
      code: err.code || "INTERNAL_ERROR",
      message: status >= 500 ? "An unexpected server error occurred" : err.message
    }
  });
}
